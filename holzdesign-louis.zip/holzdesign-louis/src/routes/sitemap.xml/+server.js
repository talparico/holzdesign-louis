import { SvelteKitSitemapSimple } from 'svelte-sitemap/src/index.js';

/** @type {import('./$types').RequestHandler} */
export async function GET() {
  const site = 'https://www.holzdesign-louis.ch';
  const pages = [
    '',
    '/portfolio',
    '/blog',
    '/kontakt',
    '/leistungen/massmöbel',
    '/leistungen/küchendesign',
    '/leistungen/innenausbau',
    '/leistungen/gewerbeprojekte',
    '/über-uns',
    '/impressum',
    '/datenschutz',
  ];

  const xml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
        xmlns:xhtml="http://www.w3.org/1999/xhtml">
${pages.map(p => `  <url>
    <loc>${site}${p}</loc>
    <xhtml:link rel="alternate" hreflang="de-ch" href="${site}${p}"/>
    <changefreq>${p === '' ? 'weekly' : 'monthly'}</changefreq>
    <priority>${p === '' ? '1.0' : '0.8'}</priority>
  </url>`).join('\n')}
</urlset>`;

  return new Response(xml, {
    headers: {
      'Content-Type': 'application/xml',
      'Cache-Control': 'max-age=3600'
    }
  });
}
