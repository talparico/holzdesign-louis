# Holzdesign Louis – Website

SvelteKit-Website mit Decap CMS (ehemals Netlify CMS), gehostet auf Netlify.

---

## 🚀 Schritt-für-Schritt: GitHub → Netlify → CMS

### SCHRITT 1 – GitHub Repository erstellen

1. Gehe auf [github.com](https://github.com) und melde dich an
2. Klicke auf **«New repository»** (grüner Button)
3. Name: `holzdesign-louis`
4. Sichtbarkeit: **Public** (für Netlify kostenlos nötig)
5. Klicke **«Create repository»**

### SCHRITT 2 – Projekt auf GitHub hochladen

Führe diese Befehle im Projektordner aus:

```bash
git init
git add .
git commit -m "Initial commit: Holzdesign Louis Website"
git branch -M main
git remote add origin https://github.com/DEIN-USERNAME/holzdesign-louis.git
git push -u origin main
```

> ⚠️ `DEIN-USERNAME` durch deinen echten GitHub-Benutzernamen ersetzen

### SCHRITT 3 – Netlify verbinden

1. Gehe auf [app.netlify.com](https://app.netlify.com)
2. Klicke **«Add new site»** → **«Import an existing project»**
3. Wähle **GitHub** → Autorisiere Netlify
4. Wähle dein Repository **holzdesign-louis**
5. Build-Einstellungen (werden automatisch erkannt):
   - Build command: `npm run build`
   - Publish directory: `build`
6. Klicke **«Deploy site»**

### SCHRITT 4 – Netlify Identity aktivieren (für CMS-Login)

1. Im Netlify Dashboard → **«Site settings»** → **«Identity»**
2. Klicke **«Enable Identity»**
3. Unter **«Registration»**: Wähle **«Invite only»** (Sicherheit!)
4. Unter **«Services»** → **«Git Gateway»** → **«Enable Git Gateway»**

### SCHRITT 5 – Deinen CMS-Benutzer erstellen

1. Im Netlify Dashboard → **«Identity»** → **«Invite users»**
2. Gib deine E-Mail-Adresse ein
3. Du erhältst eine Einladungs-E-Mail → Passwort festlegen

### SCHRITT 6 – config.yml anpassen

Öffne `static/admin/config.yml` und ersetze:
```yaml
backend:
  repo: DEIN-GITHUB-USERNAME/holzdesign-louis
```

Dann erneut pushen:
```bash
git add .
git commit -m "CMS config: GitHub repo eingetragen"
git push
```

### SCHRITT 7 – CMS aufrufen

Gehe auf: `https://deine-netlify-url.netlify.app/admin`

Fertig! Du kannst jetzt Blog-Artikel und Projekte direkt im Browser verwalten.

---

## 📁 Projektstruktur

```
holzdesign-louis/
├── src/
│   ├── lib/
│   │   └── components/
│   │       ├── Nav.svelte        # Navigation
│   │       ├── Footer.svelte     # Footer
│   │       └── SeoHead.svelte    # SEO Meta-Tags
│   ├── routes/
│   │   ├── +layout.svelte        # Grundlayout
│   │   ├── +page.svelte          # Homepage
│   │   └── sitemap.xml/          # Sitemap
│   ├── app.css                   # Globale Styles
│   └── app.html                  # HTML-Template
├── static/
│   ├── admin/
│   │   ├── index.html            # Decap CMS
│   │   └── config.yml            # CMS Konfiguration
│   ├── images/                   # Bilder hier ablegen
│   └── robots.txt
├── netlify.toml
└── svelte.config.js
```

## 🖼️ Bilder einfügen

Lege deine Bilder in `static/images/` ab:
- `hero-holzbearbeitung.jpg`
- `louis-portrait.jpg`
- `werkstatt.jpg`
- `leistung-1.jpg` bis `leistung-4.jpg`

## 🌐 Eigene Domain

Im Netlify Dashboard → **«Domain settings»** → **«Add custom domain»**

---

## 📝 Lokale Entwicklung

```bash
npm install
npm run dev
```

Öffne [http://localhost:5173](http://localhost:5173)
